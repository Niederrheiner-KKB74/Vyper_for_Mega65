Stage 3a - Datenpaket (kein fertiger Stage-3a-Lader)

VYLV.DAT: 81793 Bytes, 100 Levels, Format VYLV v1.
VYGR.DAT: 30888 Bytes, Format VYGR v1.
  Offset 0: ASCII VYGR
  Offset 4: WORD little-endian version=1
  Offset 6: WORD little-endian type_count=36
  Offset 8: 36 Eintraege zu je 8 Bytes, geordnet type_01..type_36:
    DWORD little-endian Datei-Offset des ersten Frames
    WORD little-endian Anzahl Frames
    WORD little-endian reserviert=0
  Danach 239 Frames in Reihenfolge, je 128 Bytes.

VYPER_STAGE3A_GRAPHICS_DATA_DISK.d81:
  VYPER3A = unveraenderte Stage 2ja PRG (keine Ladefunktion)
  VYLV.DAT = integrierte Leveldaten
  VYGR.DAT = alle NCM-Grafiken

Alle drei D81-Dateiketten wurden bytegenau rueckgelesen und verifiziert.
ACHTUNG: Eine 45GS02/KERNAL/DMAgic-Laderoutine und ein Level-Setup
sind in diesem Stand NOCH NICHT implementiert. Dies ist ein
Daten-/Datentraeger-Zwischenstand, kein fertiger Stage-3a-Testbuild.

Offene Datenfrage: Level-Grafiktypindizes 0..37, NCM-Typen 1..36.
Mehrere Level haben mehr als vier unterschiedliche Typindizes.
Die Zuordnung und Slot-Strategie muessen vor der Spielintegration
abgeglichen werden.
