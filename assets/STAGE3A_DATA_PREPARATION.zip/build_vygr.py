import zipfile,re,struct,hashlib,collections
from pathlib import Path
root=Path('/mnt/data'); src=zipfile.ZipFile(root/'vyper_all_enemy_types_exact_ncm.zip')
types=collections.defaultdict(dict)
for n in src.namelist():
 m=re.fullmatch(r'type_(\d+)/anim_(\d+)_ncm\.bin',n)
 if m:
  t,f=map(int,m.groups());b=src.read(n);assert len(b)==128
  types[t][f]=b
assert sorted(types)==list(range(1,37))
# VYGR v1: magic 4, version uint16, typecount uint16, 36 entries of offset uint32, framecount uint16, reserved uint16
out=bytearray(b'VYGR'+struct.pack('<HH',1,len(types)));cursor=8+8*len(types)
for t,frames in sorted(types.items()):
 assert sorted(frames)==list(range(len(frames)))
 out+=struct.pack('<IHH',cursor,len(frames),0);cursor+=len(frames)*128
for t,frames in sorted(types.items()):
 for f,b in sorted(frames.items()):out+=b
assert len(out)==cursor
(root/'VYGR.DAT').write_bytes(out)
print('VYGR bytes',len(out),'types',len(types),'frames',sum(map(len,types.values())),'sha256',hashlib.sha256(out).hexdigest())
