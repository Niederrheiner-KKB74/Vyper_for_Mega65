from pathlib import Path
import math,struct,hashlib
r=Path('/mnt/data'); prg=(r/'vyper_rrb_v014_stage2ja.prg').read_bytes(); lv=(r/'VYLV.DAT').read_bytes(); gr=(r/'VYGR.DAT').read_bytes()
img=bytearray(80*40*256);used={(40,0),(40,1),(40,2),(40,3)}
def at(t,s):return ((t-1)*40+s)*256
def write(t,s,buf):img[at(t,s):at(t,s)+256]=buf
def petscii(s,n):return s.upper().encode('ascii')[:n].ljust(n,b'\xa0')
available=[(t,s) for t in list(range(1,40))+list(range(41,81)) for s in range(40)]
def add_file(payload):
 count=math.ceil(len(payload)/254);chain=available[:count];del available[:count];used.update(chain)
 for i,(t,s) in enumerate(chain):
  chunk=payload[i*254:(i+1)*254];sec=bytearray(256)
  if i+1<len(chain):sec[0],sec[1]=chain[i+1]
  else:sec[0],sec[1]=0,len(chunk)+1
  sec[2:2+len(chunk)]=chunk;write(t,s,sec)
 return chain[0],count
entries=[('VYPER3A',prg,0x82),('VYLV.DAT',lv,0x81),('VYGR.DAT',gr,0x81)]
dirsec=bytearray(256);dirsec[0:2]=bytes([0,255])
for i,(name,payload,ftype) in enumerate(entries):
 (t,s),blocks=add_file(payload);off=2+i*32;dirsec[off]=ftype;dirsec[off+1:off+3]=bytes([t,s]);dirsec[off+3:off+19]=petscii(name,16);dirsec[off+30:off+32]=struct.pack('<H',blocks)
write(40,3,dirsec)
header=bytearray(256);header[0:4]=bytes([40,3,0x44,0]);header[4:20]=petscii('VYPER STAGE 3A',16);header[0x16:0x1b]=b'3A\xa02A';write(40,0,header)
for index,trackrange in enumerate((range(1,41),range(41,81))):
 bam=bytearray(256);bam[0:2]=bytes([40,2 if index==0 else 1]);bam[2]=0x44;bam[4:6]=b'3A'
 for j,t in enumerate(trackrange):
  free=[s for s in range(40) if (t,s) not in used];off=0x10+j*6;bam[off]=len(free)
  for s in free:bam[off+1+s//8]|=1<<(s%8)
 write(40,1+index,bam)
for i,(name,payload,_) in enumerate(entries):
 o=2+i*32;t,s=dirsec[o+1:o+3];got=bytearray();visited=set()
 while t:
  assert (t,s) not in visited;visited.add((t,s));sec=img[at(t,s):at(t,s)+256];nt,ns=sec[:2];got+=sec[2:256 if nt else ns+1];t,s=nt,ns
 assert got==payload,(name,len(got),len(payload))
out=r/'VYPER_STAGE3A_GRAPHICS_DATA_DISK.d81';out.write_bytes(img)
print('disk verified',len(img),'free',len(available),'sha256',hashlib.sha256(img).hexdigest())
