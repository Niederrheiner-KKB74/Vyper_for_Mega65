Stage6a2 / Issue45: independent original 320x200 menu, 32 animated types plus original COLOR02 cycling. NOT Stable.
Mount releases/stage_6a2/VYPER_STAGE6A2.d81. LOAD"STAGE6A2",8 then RUN. Only X exits; menu options do nothing.
Full generated ASM and binary inputs are inside releases/stage_6a2/. Reproducible conversion/build/testing uses Git branch stage6a2 with original repository assets and Stable tags.
See docs/stage6a2_color_cycling.md for original evidence and XEMU acceptance.
