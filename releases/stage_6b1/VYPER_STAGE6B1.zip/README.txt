Stage6b1 / Issue47. TEST BUILD, NOT Stable.
Mount releases/stage_6b1/VYPER_STAGE6B1.d81; LOAD"STAGE6B1",8 then RUN.
Original title stays visible during loading, then the animated menu appears.
Joystick2/cursors navigate; F1 starts selected level; F2/F3 placeholders; X exits.
Full repository and protected stable assets/tags required for rebuild.
