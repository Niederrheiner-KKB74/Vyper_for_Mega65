Stage7b4 / Issue59. TEST BUILD, NOT Stable.
Mount releases/stage_7b4/VYPER_STAGE7B4.d81; LOAD"STAGE7B4",8 then RUN.
Original title/loader/menu first; F1 starts the full game; Original3x7 shots, player red tip up/enemy down; 2 player+6 enemy projectiles, at most2 per original enemy;30-frame attack cadence; LEVEL CLEAR fire starts transition.
Joystick PORT2. Blue 1px/8 frames, red /4, yellow /2; accepted Stage7a1 parameters.
No star test keys or profiler. X BASIC, R after GAME OVER, +/- levels.
No XEMU test claimed; please confirm Original3x7 shots, centre-out colour/black wipe and BASIC/RUN tests.
Full repository with original assets and protected stable tags required to rebuild.
Build, measurements and test limits: docs/stage7b4_per_enemy_shot_limit.md.
