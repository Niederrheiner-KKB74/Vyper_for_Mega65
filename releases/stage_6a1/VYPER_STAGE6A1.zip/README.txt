Stage6a1 / Issue43: independent original 320x200 menu, 32 animated types. NOT Stable.
Mount releases/stage_6a1/VYPER_STAGE6A1.d81. LOAD"STAGE6A1",8 then RUN. Only X exits; menu options do nothing.
Full generated ASM and binary inputs are inside releases/stage_6a1/. Reproducible conversion/build/testing uses Git branch stage6a1 with original repository assets and Stable tags.
See docs/stage6a1_start_screen_visual.md for original evidence and XEMU acceptance.
