Issue37: three independent Debut-Y tests; NONE Stable.
A: Y; B: Y-16; C: floor(Y*25/29). ENTRY only.
Each A/B/C directory contains a complete D81 with its PRG and all 3 game DATs.
Mount A/VYPER_Y_A.D81 (inside releases/debut_y_geometry_test/) and
LOAD "VYPER_Y_A",8 then RUN. B/C equivalent. + and - select levels.
German comparison tables and XEMU test: docs/debut_y_geometry_comparison.md.
Generated full ASM and symbols are included. For reproducible builds/tests,
use Git branch test-debut-y-geometry with stage5c-stable tag and original repo assets.
python tools/build_debut_y_geometry.py --variant all --kickass /path/to/KickAss.jar
No own XEMU/Amiga acceptance is claimed. User comparison is pending.
