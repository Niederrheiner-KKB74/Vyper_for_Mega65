Stage7a2 / Issue51. TEST BUILD, NOT Stable.
Mount releases/stage_7a2/VYPER_STAGE7A2.d81; LOAD"STAGE7A2",8 then RUN.
Original title/loader/menu first; F1 starts the full game with the accepted starfield.
Joystick PORT2. Blue 1px/8 frames, red /4, yellow /2; accepted Stage7a1 parameters.
No star test keys or profiler. X BASIC, R after GAME OVER, +/- levels.
No XEMU test claimed; please confirm visual, LEVEL CLEAR/level continuity and BASIC/RUN tests.
Full repository with original assets and protected stable tags required to rebuild.
Build, measurements and test limits: docs/stage7a2_starfield_integration.md.
