Vyper Stage 5d-1 / Issue #35 - title during SEQ loading. NOT Stable.
Mount releases/stage_5d_1/VYPER_STAGE5D1.d81 in PAL XEMU / ROM V920395.
LOAD "STAGE5D1",8 then RUN. Title first, then automatic Level 1.
X returns to BASIC. Test DIRECTORY and repeated RUN.
German documentation: docs/stage5d1_title_loader_integration.md.
Complete engine sources, originals, converters and build tools are included.
For reproducible baseline protection and inherited regression, use the repository
branch stage5d-1 with tags stage5c-stable and stage5d0-stable fetched.
python -m pip install -r tools/stage5d0-requirements.txt
python tools/build_stage5d1.py --kickass /path/to/KickAss.jar
No own XEMU/hardware success is claimed; user acceptance is pending.
