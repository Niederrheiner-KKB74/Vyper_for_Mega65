// Issue #16. Original bytes; explicit MEGA65 scheduling/selection/exit rules.
.namespace attack {
.const a_FORM_STEP_TICKS=10
.const a_FORM_Y_SHIFT=8 // one character row; applies to every parsed formation target
.const a_FORM_MIN=-8
.const a_FORM_MAX=8
.const a_START_INTERVAL=60
.const a_INITIAL_INTERVAL=100
.const a_SEED=$c3a5 // reproducible, nonzero Galois LFSR shared with projectile rolls
.const a_EXIT_DY=2 // after finite packed curve, continue vertically until fully outside
.label a_index=$6F80 // 22 original raw attack indices
.label a_anchorx=$6F96
.label a_anchory=$6FAC
.label a_hidden=$6FC2 // bottom-crossing latch while consuming remaining original bytes
.label a_ptrlo=$6FD8 // two bounded curve pointers in $7600 level copy
.label a_ptrhi=$6FDA
.label a_length=$6FDC
.label a_enabled=$6FDE
.label a_ready=$6FDF
.label a_offset=$6FE0 // signed -8..8
.label a_direction=$6FE1 // +1 or -1
.label a_form_tick=$6FE2
.label a_start_tick=$6FE3
.label a_count=$6FE4
.label a_shots=$6FE5
.label a_last=$6FE6
.label a_goalx=$6FE7
.label a_candidate=$6FE8
.label a_source=$6FE9
.label a_event=$6FEA // 1 attack start, 2 bottom crossing, 3 top return
.label a_event_enemy=$6FEB

*=$4b4a "Stage 4b-2 bounded attack parser"
a_init:
    lda #0
    ldx #($6FFF-$6F96)
!clear:
    sta $6F96,x
    dex
    bpl !clear-
    lda $7606
    cmp #2
    beq !near+
    jmp a_invalid
!near:
    lda $7607
    beq !near+
    jmp a_invalid
!near:
    ldx #0
!indices:
    lda a_index,x
    cmp #2
    bcc !near+
    jmp a_invalid
!near:
    inx
    cpx #22
    bne !indices-
    ldx #0
!curve:
    stx a_candidate
    jsr s3b2.read_word
    bcc !near+
    jmp a_invalid
!near:
    lda s3b2.word_value+1
    beq !near+
    jmp a_invalid
!near:
    lda s3b2.word_value
    cmp #183
    beq !near+
    jmp a_invalid
!near:
    ldx a_candidate
    sta a_length,x
    lda s3b2.pointer
    sta a_ptrlo,x
    lda s3b2.pointer+1
    sta a_ptrhi,x
    jsr s3b2.skip_curve
    bcc !near+
    jmp a_invalid
!near:
    ldx a_candidate
    inx
    cpx #2
    bne !curve-
    lda s3b2.pointer
    cmp #<$7951
    beq !near+
    jmp a_invalid
!near:
    lda s3b2.pointer+1
    cmp #>$7951
    beq !near+
    jmp a_invalid
!near:
    lda #1
    sta a_enabled
    sta a_direction
    lda #a_FORM_STEP_TICKS
    sta a_form_tick
    lda #a_INITIAL_INTERVAL
    sta a_start_tick
    lda #<a_SEED
    sta shots.p_random_lo
    lda #>a_SEED
    sta shots.p_random_hi
    rts
a_invalid:
    jmp entry.e_invalid

.if (* > $4c00) { .error "Attack parser overlaps game state code" }
*=$4f00 "Stage 4b-2 formation and selection"
a_objects:
    jsr a_preframe
    jmp entry.e_objects

a_preframe:
    lda game.c_ps
    cmp #4
    beq !done+
    lda shots.p_test_enabled
    bne !done+
    lda a_enabled
    beq !done+
    lda a_ready
    beq !done+
    dec a_form_tick
    bne !done+
    lda #a_FORM_STEP_TICKS
    sta a_form_tick
    lda a_offset
    clc
    adc a_direction
    sta a_offset
    cmp #a_FORM_MAX
    beq !left+
    cmp #(256+a_FORM_MIN)
    bne !done+
    lda #1
    sta a_direction
    rts
!left:
    lda #$ff
    sta a_direction
!done:
    rts

a_postframe:
    lda game.c_ps
    cmp #4
    beq !done+
    lda shots.p_test_enabled
    bne !done+
    lda a_enabled
    beq !done+
    lda a_ready
    bne !schedule+
    ldx #0
!barrier:
    lda game.c_es,x
    beq !next+
    cmp #4
    beq !next+
    lda entry.e_phase,x
    cmp #3
    bne !done+
!next:
    inx
    cpx #22
    bne !barrier-
    lda #1
    sta a_ready
    rts // first movement/attack countdown begins on the next update
!schedule:
    // Drain current attacks before c_wait revives the player.
    lda game.c_ps
    cmp #1
    beq !done+
    cmp #2
    beq !done+
    jsr a_recount
    lda a_start_tick
    beq !select+
    dec a_start_tick
    bne !done+
!select:
    lda #a_START_INTERVAL
    sta a_start_tick
    lda a_count
    cmp #3
    bcs !done+
    jsr shots.p_random_step
    lda shots.p_random_lo
    and #31
    cmp #22
    bcs !done+ // rejection, no biased modulo or forced attack on another slot
    tax
    lda game.c_es,x
    cmp #1
    bne !done+
    lda entry.e_phase,x
    cmp #3
    bne !done+
    jsr a_start
    jsr a_recount
!done:
    rts

.if (* > $5000) { .error "Scheduler overlaps BASIC colour backup" }
*=$9a56 "Stage 4b-2 attack start and visibility"
a_recount:
    lda #0
    sta a_count
    ldx #0
!enemy:
    lda game.c_es,x
    cmp #3
    bne !next+
    inc a_count
!next:
    inx
    cpx #22
    bne !enemy-
    rts

a_start:
    stx a_last
    stx a_event_enemy
    lda #1
    sta a_event
    lda entry.e_xlo,x
    sta a_anchorx,x
    lda entry.e_ylo,x
    sta a_anchory,x
    lda #0
    sta entry.e_cursor,x
    sta a_hidden,x
    lda #4
    sta entry.e_phase,x
    lda #3
    sta game.c_es,x
    rts

a_formation_y:
    cmp #185
    bcs !bad+
    cmp #a_FORM_Y_SHIFT
    bcc !bad+
    sec
    sbc #a_FORM_Y_SHIFT
    clc
    rts
!bad:
    sec
    rts

a_goal:
    lda entry.e_tx,x
    clc
    adc a_offset
    sta a_goalx
    rts

a_visible:
    lda game.c_es,x
    cmp #3
    bne !yes+
    lda a_hidden,x
    bne !no+
!yes:
    lda #1
    rts
!no:
    lda #0
    rts
// The explicit old T demo shares the same global ATTACK cap.
a_legacy_attack:
    lda game.c_ps
    cmp #1
    beq !blocked+
    cmp #2
    beq !blocked+
    jsr a_recount
    lda a_count
    cmp #3
    bcc !allow+
    lda game.c_es+18
    cmp #3
    beq !allow+ // already one of the three; caller verified legacy phase 3
!blocked:
    lda #0
    sta shots.p_attacking
    rts
!allow:
    jmp shots.p_test_attack
.if (* > $9b00) { .error "Attack helpers overlap projectile direction code" }

*=$9f10 "Stage 4b-2 original attack motion"
a_step:
    jsr entry.e_demo_step
    bcs a_handled
    lda entry.e_phase,x
    cmp #4
    beq a_curve
    cmp #5
    bne !near+
    jmp a_exit
!near:
    cmp #3
    bne a_unhandled
    lda shots.p_test_enabled
    bne a_unhandled
    jsr a_goal
    lda a_goalx
    sta entry.e_xlo,x
    lda #0
    sta entry.e_xhi,x
    jsr entry.e_mirror
    sec
    rts
a_unhandled:
    clc
    rts
a_handled:
    sec
    rts

a_curve:
    lda a_index,x
    tay
    clc
    lda a_ptrlo,y
    adc entry.e_cursor,x
    sta a_read+1
    lda a_ptrhi,y
    adc #0
    sta a_read+2
a_read:
    lda $7600
    sta entry.e_byte
    lsr
    lsr
    lsr
    lsr
    jsr entry.e_decode
    sta entry.e_dx
    lda entry.e_byte
    and #15
    jsr entry.e_decode
    sta entry.e_dy
    clc
    lda entry.e_xlo,x
    adc entry.e_dx
    sta entry.e_xlo,x
    lda #0
    bit entry.e_dx
    bpl !xp+
    lda #$ff
!xp:
    adc entry.e_xhi,x
    sta entry.e_xhi,x
    clc
    lda entry.e_ylo,x
    adc entry.e_dy
    sta entry.e_ylo,x
    lda #0
    bit entry.e_dy
    bpl !yp+
    lda #$ff
!yp:
    adc entry.e_yhi,x
    sta entry.e_yhi,x
    inc entry.e_cursor,x
    jsr a_bottom
    lda a_index,x
    tay
    lda entry.e_cursor,x
    cmp a_length,y
    bne !mirror+
    lda #5
    sta entry.e_phase,x
!mirror:
    jsr entry.e_mirror
    sec
    rts

a_bottom:
    lda entry.e_yhi,x
    bmi !done+
    bne !outside+
    lda entry.e_ylo,x
    cmp #200
    bcc !done+
!outside:
    lda a_hidden,x
    bne !done+
    lda #1
    sta a_hidden,x
    lda #2
    sta a_event
    stx a_event_enemy
!done:
    rts

.if (* > $a000) { .error "Attack motion enters ROM-overlay range" }
*=$36b0 "Stage 4b-2 bottom exit and top reentry"
a_exit:
    // No negative expanded endmarker is stored in VYLV. Finite-length fallback.
    lda entry.e_yhi,x
    bne a_reentry
    lda entry.e_ylo,x
    cmp #200
    bcs a_reentry
    clc
    adc #a_EXIT_DY
    sta entry.e_ylo,x
    bcc !nohi+
    inc entry.e_yhi,x
!nohi:
    jsr a_bottom
    jsr entry.e_mirror
    sec
    rts
a_reentry:
    // One completely invisible bottom frame, then Y=-16 above the visible area.
    lda #$f0
    sta entry.e_ylo,x
    lda #$ff
    sta entry.e_yhi,x
    lda #2
    sta entry.e_phase,x
    sta game.c_es,x
    lda #0
    sta a_hidden,x
    lda #3
    sta a_event
    stx a_event_enemy
    jsr entry.e_mirror
    sec
    rts

// Reuse the existing 8.8 direction calculation, global slots 2..5 and publisher.
.if (* > $3700) { .error "Attack reentry overlaps player integration" }
*=$895c "Stage 4b-2 enemy fire selection"
a_fire:
    lda shots.p_test_enabled
    beq !normal+
    jmp shots.p_enemy_fire // retained isolated T demonstration
!normal:
    lda a_ready
    bne !near+
    jmp a_fire_done
!near:
    lda shots.p_cooldown
    beq !roll+
    dec shots.p_cooldown
    jmp a_fire_count
!roll:
    lda shots.p_random_lo
    and #7
    beq !near+
    jmp a_fire_count
!near:
    lda shots.p_random_hi
    and #31
    cmp #22
    bcc !near+
    jmp a_fire_count
!near:
    tax
    lda game.c_es,x
    cmp #3
    beq !near+
    jmp a_fire_count
!near:
    jsr a_visible
    bne !near+
    jmp a_fire_count
!near:
    lda entry.e_xhi,x
    ora entry.e_yhi,x
    beq !near+
    jmp a_fire_count
!near:
    lda entry.e_xlo,x
    cmp #225
    bcc !near+
    jmp a_fire_count
!near:
    lda entry.e_ylo,x
    cmp #181
    bcc !near+
    jmp a_fire_count
!near:
    stx a_source
    ldx #2
!slot:
    lda shots.p_active,x
    bne !busy+
    jmp a_fire_start
!busy:
    inx
    cpx #6
    bne !slot-
    jmp a_fire_count

.if (* > $8a00) { .error "Fire selection overlaps projectile graphics" }
*=$7951 "Stage 4b-2 aimed shot initialization"
a_fire_start:
    stx shots.p_slot
    lda V014_PLAYER+2
    clc
    adc #8
    sta shots.p_target_x,x
    lda V014_PLAYER+4
    sta shots.p_target_y,x
    ldy a_source
    lda entry.e_xlo,y
    clc
    adc #8
    sta shots.p_xpos,x
    lda entry.e_ylo,y
    clc
    adc #16
    sta shots.p_ypos,x
    lda shots.p_target_y,x
    sec
    sbc shots.p_ypos,x
    bcs !near+
    jmp a_fire_count
!near:
    bne !near+
    jmp a_fire_count
!near:
    sta shots.p_denominator
    lda shots.p_target_x,x
    sec
    sbc shots.p_xpos,x
    sta shots.p_dx
    lda #0
    sta shots.p_negative
    bcs !positive+
    inc shots.p_negative
    lda shots.p_dx
    eor #$ff
    clc
    adc #1
    sta shots.p_dx
!positive:
    jsr shots.p_direction
    ldx shots.p_slot
    lda shots.p_numerator
    sta shots.p_vxfrac,x
    lda shots.p_numerator+1
    sta shots.p_vx,x
    lda #0
    sta shots.p_xfrac,x
    sta shots.p_yfrac,x
    sta shots.p_vyfrac,x
    lda a_source
    sta shots.p_source_enemy,x
    lda #1
    sta shots.p_vy,x
    lda #1
    sta shots.p_active,x
    lda #12
    sta shots.p_cooldown

a_fire_count:
    lda #0
    sta a_shots
    ldx #2
!count:
    lda shots.p_active,x
    beq !next+
    inc a_shots
!next:
    inx
    cpx #6
    bne !count-
a_fire_done:
    rts
.if (* > $7a00) { .error "Shot initialization overlaps HUD tables" }
.if (a_SEED<1 || a_SEED>65535) { .error "LFSR seed must be nonzero 16-bit" }
.if (a_FORM_STEP_TICKS<1 || a_FORM_STEP_TICKS>255) { .error "Invalid formation cadence" }
}
