Stage 5d-1a / Issue41. Integrated title-loader plus confirmed B2 ENTRY correction. NOT Stable.
Mount releases/stage_5d_1_b2/VYPER_STAGE5D1A.d81, LOAD"STAGE5D1A",8 then RUN.
Original repository/tag assets are required to rebuild. See included technical documentation.
