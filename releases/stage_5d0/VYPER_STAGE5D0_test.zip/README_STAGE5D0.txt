Vyper Stage 5d-0 / Issue #33 - isolated original-title test, NOT Stable.
PAL / ROM V920395 / BASIC 80x25. Mount releases/stage_5d0/VYPER_STAGE5D0.d81.
LOAD "STAGE5D0",8 then RUN. X/x returns to BASIC. Test DIRECTORY and RUN again.
Full details: docs/stage5d0_title_test.md (German).
Source and assets are included. Rebuild from the GitHub stage5d-title-test branch
with stage5c-stable fetched: build script protects that baseline using Git.
python tools/build_stage5d0.py --kickass /path/to/KickAss.jar
No own XEMU/hardware or executed Amiga-Copper trace is claimed.
