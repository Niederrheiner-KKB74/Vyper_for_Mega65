Stage7b5a / Issue63. TEST BUILD, NOT Stable.
Mount releases/stage_7b5a/VYPER_STAGE7B5A.d81; LOAD"STAGE7B5A",8 then RUN.
Original title/loader/menu first; F1 starts the full game; Original3x7 shots, player red tip up/enemy down; 2 player+6 enemy projectiles, no owner quota;30-frame attack cadence; LEVEL CLEAR fire starts transition.
Joystick PORT2. Blue 1px/8 frames, red /4, yellow /2; accepted Stage7a1 parameters.
No star test keys or profiler. X BASIC, R after GAME OVER, +/- levels.
No XEMU test claimed; please confirm original event timing in levels1/3/29/54, six-shot cap and BASIC/RUN tests.
Full repository with original assets and protected stable tags required to rebuild.
Build, measurements and test limits: docs/stage7b5a_original_fire_events.md.
