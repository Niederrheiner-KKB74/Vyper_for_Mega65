Stage7a1 / Issue49. TEST BUILD, NOT Stable.
Mount releases/stage_7a1/VYPER_STAGE7A1.d81; LOAD"STAGE7A1",8 then RUN.
Original title/loader/menu first; F1 starts the starfield game test.
Joystick PORT2. Blue 1px/8 frames, red /4, yellow /2; test parameters.
B stars off/on; V profiling border; X BASIC exit. All old controls retained.
No XEMU test claimed; please confirm visual, real raster and BASIC/RUN tests.
Full repository with original assets and protected stable tags required to rebuild.
Build, measurements and test limits: docs/stage7a1_starfield_feasibility.md.
