Stage7b5b / Issue65. TEST, NOT Stable.
Mount VYPER_STAGE7B5B.d81, LOAD"STAGE7B5B",8 then RUN. Joystick PORT2.
F1 starts game. Player default2px/50Hzframe is adjustable TEST value, not proven native effective speed.
Original per-update enemy motion; see docs/stage7b5b_player_and_projectile_motion.md.
Full repository with protected Git references and original inputs required to rebuild.
XEMU acceptance pending.
