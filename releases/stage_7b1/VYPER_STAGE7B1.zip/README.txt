Stage7b1 / Issue53. TEST BUILD, NOT Stable.
Mount releases/stage_7b1/VYPER_STAGE7B1.d81; LOAD"STAGE7B1",8 then RUN.
Original title/loader/menu first; F1 starts the full game; white1x4 shots; LEVEL CLEAR fire starts transition.
Joystick PORT2. Blue 1px/8 frames, red /4, yellow /2; accepted Stage7a1 parameters.
No star test keys or profiler. X BASIC, R after GAME OVER, +/- levels.
No XEMU test claimed; please confirm white shots, centre-out colour/black wipe and BASIC/RUN tests.
Full repository with original assets and protected stable tags required to rebuild.
Build, measurements and test limits: docs/stage7b1_level_transition.md.
